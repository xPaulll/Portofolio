@extends('portfolio')

@section('title', 'Detail Proyek - Reverse Osmosis WT')

@section('content')
<section class="space-y-6">
    <a href="{{ route('projects') }}"
       class="inline-flex items-center text-xs text-zinc-400 hover:text-accent transition-colors">
        <span class="mr-1">&larr;</span> Kembali ke daftar proyek
    </a>

    <header class="space-y-3">
        <div class="flex flex-wrap items-start justify-between gap-3">
            <div>
                <p class="text-xs uppercase tracking-[0.25em] text-zinc-400 mb-1">PROYEK</p>
                <h1 class="text-2xl md:text-3xl font-semibold text-zinc-100">
                    Reverse Osmosis Water Treatment System
                </h1>
            </div>
            <div class="text-right">
                <p class="text-[11px] text-zinc-400 uppercase tracking-[0.2em]">Periode</p>
                <p class="text-sm font-medium text-zinc-100">2023</p>
            </div>
        </div>

        <p class="text-sm text-zinc-300 max-w-3xl">
            Sistem pemurnian air berbasis Reverse Osmosis (RO) dengan kontrol otomasi menggunakan PLC
            dan antarmuka HMI untuk memonitor tekanan, aliran, dan kualitas air hasil.
        </p>

        <div class="flex flex-wrap gap-1.5 text-[11px]">
            <span class="px-2 py-1 rounded-full bg-zinc-900 border border-zinc-800 text-zinc-300">PLC</span>
            <span class="px-2 py-1 rounded-full bg-zinc-900 border border-zinc-800 text-zinc-300">HMI</span>
        </div>
    </header>

    <div class="grid md:grid-cols-3 gap-6">
        <div class="md:col-span-2 space-y-6">
            <section class="space-y-2">
                <h2 class="text-sm font-semibold text-zinc-100">Ringkasan Proyek</h2>
                <p class="text-xs text-zinc-300 leading-relaxed">
                    Silakan isi bagian ini dengan deskripsi lengkap sistem, komponen utama (pompa, membran RO,
                    sensor tekanan, flowmeter, dsb.), serta bagaimana sistem kontrol diimplementasikan.
                </p>
            </section>

            <section class="space-y-2">
                <h2 class="text-sm font-semibold text-zinc-100">Dokumentasi</h2>
                <p class="text-xs text-zinc-300">
                    Anda bisa menambahkan:
                </p>
                <ul class="text-xs text-zinc-300 space-y-1.5 list-disc list-inside">
                    <li>Diagram P&ID atau skema alir sistem.</li>
                    <li>Screenshot tampilan HMI (monitoring tekanan, alarm, status pompa, dsb.).</li>
                    <li>Catatan setting parameter proses dan SOP pengoperasian.</li>
                </ul>
            </section>

            <section class="space-y-2">
                <h2 class="text-sm font-semibold text-zinc-100">Pencapaian</h2>
                <p class="text-xs text-zinc-300">
                    Tambahkan poin seperti stabilitas kualitas air, efisiensi operasi, atau manfaat bagi pengguna akhir.
                </p>
            </section>
        </div>

        <aside class="space-y-4">
            <div class="border border-zinc-800 rounded-2xl bg-zinc-950/70 p-4 text-[11px] text-zinc-300 space-y-2">
                <h2 class="text-xs font-semibold text-zinc-100">Catatan Pengembangan</h2>
                <p>
                    Bagian ini bisa Anda gunakan untuk menuliskan peran Anda (misalnya: pemrograman PLC,
                    desain HMI, commissioning di lapangan, dsb.).
                </p>
            </div>
        </aside>
    </div>
</section>
@endsection

