@extends('portfolio')

@section('title', 'Detail Proyek - SC-MANURI')

@section('content')
<section class="space-y-6">
    <a href="{{ route('projects') }}"
       class="inline-flex items-center text-xs text-zinc-400 hover:text-accent transition-colors">
        <span class="mr-1">&larr;</span> Kembali ke daftar proyek
    </a>

    <header class="space-y-3">
        <div class="flex flex-wrap items-start justify-between gap-3">
            <div>
                <p class="text-xs uppercase tracking-[0.25em] text-zinc-400 mb-1">PROYEK</p>
                <h1 class="text-2xl md:text-3xl font-semibold text-zinc-100">
                    SC-MANURI (Sistem Cerdas Manajemen Nutrisi)
                </h1>
            </div>
            <div class="text-right">
                <p class="text-[11px] text-zinc-400 uppercase tracking-[0.2em]">Periode</p>
                <p class="text-sm font-medium text-zinc-100">2025</p>
            </div>
        </div>

        <p class="text-sm text-zinc-300 max-w-3xl">
            Integrasi Internet of Things (IoT) dan model prediktif machine learning untuk
            manajemen nutrisi dinamis pada budidaya pakcoy hidroponik. Sistem ini dirancang
            untuk membantu pelaku budidaya menjaga konsistensi kualitas nutrisi secara realtime
            dan terdokumentasi.
        </p>

        <div class="flex flex-wrap gap-1.5 text-[11px]">
            <span class="px-2 py-1 rounded-full bg-zinc-900 border border-zinc-800 text-zinc-300">IoT</span>
            <span class="px-2 py-1 rounded-full bg-zinc-900 border border-zinc-800 text-zinc-300">Rest API</span>
            <span class="px-2 py-1 rounded-full bg-zinc-900 border border-zinc-800 text-zinc-300">Laravel</span>
            <span class="px-2 py-1 rounded-full bg-zinc-900 border border-zinc-800 text-zinc-300">Dashboard</span>
        </div>
    </header>

    <div class="grid md:grid-cols-3 gap-6">
        <div class="md:col-span-2 space-y-6">
            <section class="space-y-2">
                <h2 class="text-sm font-semibold text-zinc-100">Ringkasan Proyek</h2>
                <p class="text-xs text-zinc-300 leading-relaxed">
                    SC-MANURI menggabungkan sensor lingkungan, modul IoT, dan backend Laravel untuk
                    mengumpulkan data pH, EC, suhu, dan parameter lain secara berkala. Data kemudian
                    diproses oleh model machine learning untuk memberikan rekomendasi penyesuaian nutrisi
                    yang lebih presisi serta histori yang mudah ditelusuri.
                </p>
            </section>

            <section class="space-y-2">
                <h2 class="text-sm font-semibold text-zinc-100">Dokumentasi Teknis</h2>
                <ul class="text-xs text-zinc-300 space-y-1.5 list-disc list-inside">
                    <li>Arsitektur sistem berbasis IoT dengan node sensor yang mengirim data melalui protokol HTTP/MQTT ke server Laravel.</li>
                    <li>API terproteksi yang menyimpan dan menyediakan data untuk dashboard monitoring.</li>
                    <li>Dashboard web responsif untuk melihat tren parameter nutrisi, log peristiwa, dan rekomendasi tindakan.</li>
                    <li>Pencatatan manual (manual override) yang memungkinkan pengguna menambahkan catatan lapangan, foto, atau kejadian khusus.</li>
                </ul>
            </section>

            <section class="space-y-3">
                <h2 class="text-sm font-semibold text-zinc-100">Jadwal & Timeline</h2>
                <div class="border border-zinc-800 rounded-2xl bg-zinc-950/70 p-4 text-xs text-zinc-300 space-y-2">
                    <div class="flex justify-between">
                        <span class="text-zinc-400">Fase 1</span>
                        <span class="text-zinc-500">Riset & Perancangan</span>
                    </div>
                    <p>Pemodelan kebutuhan sistem, pemilihan sensor, studi literatur nutrisi hidroponik, dan desain arsitektur.</p>

                    <div class="border-t border-zinc-800 pt-2 flex justify-between">
                        <span class="text-zinc-400">Fase 2</span>
                        <span class="text-zinc-500">Implementasi Hardware & Backend</span>
                    </div>
                    <p>Perakitan node IoT, koneksi ke server, perancangan database, dan pengembangan API menggunakan Laravel.</p>

                    <div class="border-t border-zinc-800 pt-2 flex justify-between">
                        <span class="text-zinc-400">Fase 3</span>
                        <span class="text-zinc-500">Dashboard & Model Prediktif</span>
                    </div>
                    <p>Pengembangan antarmuka dashboard, integrasi model machine learning, dan penyesuaian berdasarkan uji coba lapangan.</p>
                </div>
            </section>

            <section class="space-y-2">
                <h2 class="text-sm font-semibold text-zinc-100">Pencapaian & Hasil</h2>
                <ul class="text-xs text-zinc-300 space-y-1.5 list-disc list-inside">
                    <li>Meningkatkan konsistensi kualitas larutan nutrisi selama periode budidaya.</li>
                    <li>Menyediakan histori lengkap perubahan nutrisi beserta konteks kondisi lingkungan.</li>
                    <li>Mempermudah proses monitoring jarak jauh dengan dashboard web yang terintegrasi.</li>
                    <li>Menjadi dasar pengembangan sistem otomasi nutrisi yang lebih lanjut di masa depan.</li>
                </ul>
            </section>
        </div>

        <aside class="space-y-4">
            <div class="border border-zinc-800 rounded-2xl bg-zinc-950/70 p-4">
                <h2 class="text-xs font-semibold text-zinc-100 mb-3">Galeri / Ilustrasi</h2>
                <div class="space-y-3 text-[11px] text-zinc-400">
                    <p>
                        Di sini Anda bisa menambahkan dokumentasi visual seperti:
                    </p>
                    <ul class="list-disc list-inside space-y-1">
                        <li>Foto instalasi hardware dan sensor.</li>
                        <li>Screenshot dashboard SC-MANURI.</li>
                        <li>Diagram arsitektur sistem.</li>
                    </ul>
                </div>
            </div>

            <div class="border border-zinc-800 rounded-2xl bg-zinc-950/70 p-4 text-[11px] text-zinc-300 space-y-2">
                <h2 class="text-xs font-semibold text-zinc-100">Peran Anda</h2>
                <p>
                    Misalnya: perancangan arsitektur sistem, pengembangan backend Laravel & API, integrasi IoT,
                    serta desain dan implementasi dashboard monitoring.
                </p>
            </div>
        </aside>
    </div>
</section>
@endsection

